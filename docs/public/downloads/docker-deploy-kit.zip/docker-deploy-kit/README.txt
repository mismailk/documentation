Docker Deploy Pipeline kit
==========================

Files for putting an Express (Node.js) app on the Docker deploy pipeline.
Follow the Developer Integration Guide; it says when to use each file.

server/                       copied to the server (guide stage 3)
  deploy.sh                   installed as /opt/deploy/deploy.sh; holds the app whitelist
  server-setup.sh             one-time, idempotent server setup (run with sudo)
  app.conf.template           template for /opt/deploy/apps/<app>-<env>.conf

templates/node-api/           filled in and copied into your app repo (guide stage 4)
  Dockerfile                  -> <app repo>/Dockerfile
  dockerignore                -> <app repo>/.dockerignore
  deploy.yml                  -> <app repo>/.github/workflows/deploy.yml

Each template starts with a "# --- placeholders" block listing its {{NAME}}
placeholders. Replace them and delete that block in your copy.
