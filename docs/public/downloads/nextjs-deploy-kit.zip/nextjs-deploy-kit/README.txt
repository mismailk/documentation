Next.js Deploy Pipeline kit
===========================

Templates for putting a Next.js app on the Docker deploy pipeline.
Follow the Next.js Deploy Pipeline guide; it says when to use each file. The
server files are in the Deploy Pipeline kit.

templates/nextjs/             filled in and copied into your app repo (guide step 3)
  Dockerfile                  -> <app repo>/Dockerfile
  dockerignore                -> <app repo>/.dockerignore
  deploy.yml                  -> <app repo>/.github/workflows/deploy.yml

Each template starts with a "# --- placeholders" block listing its {{NAME}}
placeholders. Replace them and delete that block in your copy.

Public build-time settings (the NEXT_PUBLIC_* values) are not kept in the
repo. If your app needs them, store them as the optional GitHub repository
variables PUBLIC_ENV_STAGING and PUBLIC_ENV_PRODUCTION, each holding
NEXT_PUBLIC_<NAME>=value lines (any other line is rejected); the workflow
passes the right one into the image build. These values are public: they
ship to every browser, and repository variables are not masked, so they also
show in the workflow's log.
