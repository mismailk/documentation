#!/bin/sh
# docker-entrypoint-react.sh: render nginx's listen port from PORT in the
# mounted env file, then run nginx in the foreground.
#
# PORT is read the way `node --env-file` reads it: the last PORT line wins,
# `export` is accepted, spaces around `=` are ignored and a value may be
# quoted and followed by a # comment. A missing, non-numeric or out-of-range
# PORT exits 1 before nginx starts, so `deploy`'s verify step sees the failure.
#
# ENV_FILE, CONF_DIR and CONF_TEMPLATE exist for the unit tests; the defaults
# are the container's paths.
set -eu

env_file=${ENV_FILE:-/app/.env}
conf_dir=${CONF_DIR:-/tmp/nginx/conf.d}
conf_template=${CONF_TEMPLATE:-/etc/nginx/conf.d/default.conf.template}

fail() {
  echo "react entrypoint: $*" >&2
  exit 1
}

port=
if [ -f "$env_file" ]; then
  line=$(grep -E '^[[:space:]]*(export[[:space:]]+)?PORT[[:space:]]*=' "$env_file" | tail -n 1 || true)
  if [ -n "$line" ]; then
    value=${line#*=}
    value=$(printf '%s' "$value" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
    case $value in
      \"*) value=${value#\"}; value=${value%%\"*} ;;
      \'*) value=${value#\'}; value=${value%%\'*} ;;
      *) value=${value%%[[:space:]]#*} ;;
    esac
    port=$value
  fi
fi

[ -n "$port" ] || fail "PORT is missing from $env_file"
case $port in
  *[!0-9]*) fail "PORT in $env_file must be a whole number between 1 and 65535" ;;
esac
if [ "$port" -lt 1 ] || [ "$port" -gt 65535 ]; then
  fail "PORT in $env_file must be between 1 and 65535"
fi

PORT=$port
export PORT

mkdir -p "$conf_dir"
# shellcheck disable=SC2016 # envsubst wants the literal ${PORT}, not our value.
envsubst '${PORT}' <"$conf_template" >"$conf_dir/default.conf"
exec nginx -g 'daemon off;'
