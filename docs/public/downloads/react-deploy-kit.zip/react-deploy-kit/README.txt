React Deploy Pipeline kit
=========================

Templates for putting a static React app (Vite or Create React App) on the
Docker deploy pipeline. Follow the React Deploy Pipeline guide; it says when
to use each file. The server files are in the Deploy Pipeline kit.

templates/react/              filled in and copied into your app repo (guide step 3)
  Dockerfile                  -> <app repo>/Dockerfile
  dockerignore                -> <app repo>/.dockerignore
  deploy.yml                  -> <app repo>/.github/workflows/deploy.yml
  nginx.conf.template         -> <app repo>/nginx.conf.template
  nginx-include.conf          -> <app repo>/nginx-include.conf
  docker-entrypoint.sh        -> <app repo>/docker-entrypoint.sh

The last three files are copied unchanged: the Dockerfile references them and
they turn the container's PORT into nginx's listen port. Do not edit them.

Each template starts with a "# --- placeholders" block listing its {{NAME}}
placeholders. Replace them and delete that block in your copy. The placeholders
that describe your app are:

  {{NODE_VERSION}}    Node version for the build stage, e.g. 22.12.0
  {{BUILD_COMMAND}}   the whole build command line, e.g. npm run build, or for CRA
                      npx react-scripts build && npx workbox injectManifest workbox-config.js
  {{BUILD_DIR}}       the build output folder, build (CRA) or dist (Vite)
  {{EXTRA_IGNORES}}   app-specific paths to keep out of the image
  {{PUBLIC_PREFIX}}   the public value prefix the workflow's name check accepts,
                      VITE_ or REACT_APP_

Public build-time settings (the {{PUBLIC_PREFIX}}<NAME> values) are not kept in
the repo. If your app needs them, store them as the optional GitHub repository
variables PUBLIC_ENV_STAGING and PUBLIC_ENV_PRODUCTION, each holding
{{PUBLIC_PREFIX}}<NAME>=value lines (any line without that prefix is rejected);
the workflow passes the right one into the image build. These values are
public: they ship to every browser, and repository variables are not masked, so
they also show in the workflow's log.
