Express Deploy Pipeline kit
===========================

Templates for putting an Express (Node.js) app on the Docker deploy pipeline.
Follow the Express Deploy Pipeline guide; it says when to use each file. The
server files are in the Deploy Pipeline kit.

templates/node-api/           filled in and copied into your app repo (guide step 3)
  Dockerfile                  -> <app repo>/Dockerfile
  dockerignore                -> <app repo>/.dockerignore
  deploy.yml                  -> <app repo>/.github/workflows/deploy.yml
  migrate.yml                 -> <app repo>/.github/workflows/migrate.yml

migrate.yml is the optional manual workflow that reruns one migration script
for an existing tag; you only need it if your app uses database migrations.

Each template starts with a "# --- placeholders" block listing its {{NAME}}
placeholders. Replace them and delete that block in your copy.

The Dockerfile also takes two Express-specific placeholders: {{START_SCRIPT}}
(the entry file relative to /app, e.g. dist/server.js) and {{INSTANCES}} (the
number of pm2 cluster workers, default 1).
