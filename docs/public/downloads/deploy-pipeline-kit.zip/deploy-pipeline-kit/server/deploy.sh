#!/usr/bin/env bash
# deploy.sh - generic Docker deploy, run via an SSH forced command.
# Grammar: deploy <app> <tag>   (tag: ^(staging|production)-[0-9a-f]{7,40}$)
#          migrate <app> <tag> <script> [arg ...]
# Invocation:
#   SSH:    authorized_keys has command="/opt/deploy/deploy.sh --env <env>";
#           the request comes from SSH_ORIGINAL_COMMAND and the pinned --env
#           is required and must match the tag's environment.
#   Manual: deploy.sh [--env <env>] deploy <app> <tag>   (--env optional)
# Exit codes (both commands): 0 ok, 1 runtime failure, 2 invalid request/conf,
#             3 conf missing, 4 lock timeout.
# BACKUP_PORT=<port> in the conf turns on zero-downtime deploys.

# Locale-proof bracket ranges such as [0-9a-f] (also when sourced by tests).
export LC_ALL=C

DEPLOY_ROOT="${DEPLOY_ROOT:-/opt/deploy}"

die() {
  local code="$1"
  shift
  echo "deploy: $*" >&2
  exit "$code"
}

# Leading "--env <staging|production>" from argv; sets PIN_ENV ("" if absent)
# and ARGS (the remaining arguments).
parse_pin() {
  PIN_ENV=""
  if [ "${1-}" = --env ]; then
    [ "$#" -ge 2 ] || die 2 "--env needs a value"
    case "$2" in
      staging | production) PIN_ENV="$2" ;;
      *) die 2 "invalid --env (staging or production)" ;;
    esac
    shift 2
  fi
  ARGS=("$@")
}

# Fill WORDS from SSH_ORIGINAL_COMMAND (if set) or from the arguments.
read_words() {
  WORDS=()
  if [ -n "${SSH_ORIGINAL_COMMAND+x}" ]; then
    set -f
    IFS=$' \t\n' read -r -d '' -a WORDS <<<"$SSH_ORIGINAL_COMMAND" || true
    set +f
  else
    WORDS=("$@")
  fi
}

# Validate "deploy <app> <tag>"; sets REQ_APP and REQ_TAG.
parse_request() {
  [ "$#" -eq 3 ] || die 2 "expected: deploy <app> <tag>"
  [ "$1" = deploy ] || die 2 "unknown command"
  case "$2" in
    backend) ;;
    *) die 2 "unknown app" ;;
  esac
  [[ "$3" =~ ^(staging|production)-[0-9a-f]{7,40}$ ]] || die 2 "invalid tag"
  # shellcheck disable=SC2034 # consumed by later steps in main
  REQ_APP="$2"
  # shellcheck disable=SC2034
  REQ_TAG="$3"
}

# Validate "migrate <app> <tag> <script> [arg ...]"; sets REQ_APP, REQ_TAG,
# REQ_SCRIPT and the array REQ_ARGS.
parse_migrate() {
  [ "$#" -ge 4 ] || die 2 "expected: migrate <app> <tag> <script> [arg ...]"
  [ "$1" = migrate ] || die 2 "expected: migrate <app> <tag> <script> [arg ...]"
  # The app allowlist and the tag rule live only in parse_request.
  parse_request deploy "$2" "$3"
  # No dots or slashes: the name can only select a file in dist/scripts/.
  [[ "$4" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$ ]] || die 2 "invalid script name"
  [ "$#" -le 24 ] || die 2 "too many arguments"
  local arg
  # shellcheck disable=SC2034 # consumed by later steps in main
  REQ_ARGS=()
  for arg in "${@:5}"; do
    [[ "$arg" =~ ^[A-Za-z0-9._,:=+@-]{1,200}$ ]] || die 2 "invalid argument"
    REQ_ARGS+=("$arg")
  done
  # shellcheck disable=SC2034
  REQ_SCRIPT="$4"
}

env_for_tag() {
  case "$1" in
    staging-*) echo staging ;;
    production-*) echo production ;;
  esac
}

# Parse a per-app-env conf as data (never sourced/eval'd) and set
# CONF_IMAGE, CONF_CONTAINER, CONF_PORT, CONF_BACKUP_PORT, CONF_ENV_FILE,
# CONF_MEMORY, CONF_KEEP_IMAGES. Missing file -> exit 3; any invalid content
# -> exit 2.
load_conf() {
  local path="$1" line key val
  local -A seen=()
  [ -f "$path" ] || die 3 "conf not found: $path"
  [ -r "$path" ] || die 3 "conf not readable: $path"

  while IFS= read -r line || [ -n "$line" ]; do
    [[ "$line" =~ ^[[:space:]]*(#.*)?$ ]] && continue
    [[ "$line" == *=* ]] || die 2 "conf: malformed line"
    key="${line%%=*}"
    val="${line#*=}"
    case "$key" in
      IMAGE | CONTAINER | PORT | BACKUP_PORT | ENV_FILE | MEMORY | KEEP_IMAGES) ;;
      *) die 2 "conf: unknown key" ;;
    esac
    [ -z "${seen[$key]+x}" ] || die 2 "conf: duplicate key $key"
    seen[$key]="$val"
  done <"$path"

  for key in IMAGE CONTAINER PORT ENV_FILE MEMORY KEEP_IMAGES; do
    [ -n "${seen[$key]+x}" ] || die 2 "conf: missing key $key"
  done

  # Optional "host:port/" registry prefix; no tag or digest.
  [[ "${seen[IMAGE]}" =~ ^([a-z0-9][a-z0-9.-]*:[0-9]{1,5}/)?[a-z0-9][a-z0-9./_-]*$ ]] ||
    die 2 "conf: invalid IMAGE"
  [[ "${seen[CONTAINER]}" =~ ^[a-z0-9][a-z0-9_.-]*$ ]] || die 2 "conf: invalid CONTAINER"
  [[ "${seen[PORT]}" =~ ^[0-9]{1,5}$ ]] || die 2 "conf: invalid PORT"
  ((10#${seen[PORT]} >= 1 && 10#${seen[PORT]} <= 65535)) || die 2 "conf: invalid PORT"
  CONF_BACKUP_PORT=""
  if [ -n "${seen[BACKUP_PORT]+x}" ]; then
    [[ "${seen[BACKUP_PORT]}" =~ ^[0-9]{1,5}$ ]] || die 2 "conf: invalid BACKUP_PORT"
    ((10#${seen[BACKUP_PORT]} >= 1 && 10#${seen[BACKUP_PORT]} <= 65535)) ||
      die 2 "conf: invalid BACKUP_PORT"
    ((10#${seen[BACKUP_PORT]} != 10#${seen[PORT]})) ||
      die 2 "conf: BACKUP_PORT must differ from PORT"
    # shellcheck disable=SC2034 # consumed by zero_downtime_deploy in main
    CONF_BACKUP_PORT="$((10#${seen[BACKUP_PORT]}))"
  fi
  [[ "${seen[ENV_FILE]}" =~ ^/[A-Za-z0-9._/-]+$ ]] || die 2 "conf: invalid ENV_FILE"
  [ -f "${seen[ENV_FILE]}" ] || die 2 "conf: ENV_FILE is not a regular file"
  # A zero limit means "unlimited" to Docker, so require a non-zero number.
  [[ "${seen[MEMORY]}" =~ ^0*[1-9][0-9]*[kmg]$ ]] || die 2 "conf: invalid MEMORY"
  [[ "${seen[KEEP_IMAGES]}" =~ ^[0-9]{1,6}$ ]] || die 2 "conf: invalid KEEP_IMAGES"
  ((10#${seen[KEEP_IMAGES]} >= 1)) || die 2 "conf: invalid KEEP_IMAGES"

  # shellcheck disable=SC2034 # consumed by later steps in main
  CONF_IMAGE="${seen[IMAGE]}"
  # shellcheck disable=SC2034
  CONF_CONTAINER="${seen[CONTAINER]}"
  # shellcheck disable=SC2034
  CONF_PORT="$((10#${seen[PORT]}))"
  # shellcheck disable=SC2034
  CONF_ENV_FILE="${seen[ENV_FILE]}"
  # shellcheck disable=SC2034
  CONF_MEMORY="${seen[MEMORY]}"
  # shellcheck disable=SC2034
  CONF_KEEP_IMAGES="$((10#${seen[KEEP_IMAGES]}))"
}

# Append one outcome line to the deploy log; never fails the deploy.
log_result() {
  local line
  line="$(date -u +%Y-%m-%dT%H:%M:%SZ) app=$REQ_APP env=$DEPLOY_ENV tag=$REQ_TAG result=$1"
  echo "$line" >>"$DEPLOY_ROOT/logs/deploy.log" 2>/dev/null ||
    echo "deploy: warning: could not write deploy.log: $line" >&2
}

fail_step() {
  log_result "fail:$1"
  die 1 "$1 failed"
}

# Append one migrate outcome line to the deploy log; never fails the run.
migrate_log() {
  local line
  line="$(date -u +%Y-%m-%dT%H:%M:%SZ) app=$REQ_APP env=$DEPLOY_ENV tag=$REQ_TAG result=$1"
  {
    echo "$line" >>"$DEPLOY_ROOT/logs/deploy.log" 2>/dev/null ||
      echo "deploy: warning: could not write deploy.log: $line" >&2
  } || true
}

# Stop and remove the current container (if any), then start the new one.
swap_container() {
  local existing
  existing="$(docker ps -a --filter "name=^${CONF_CONTAINER}\$" --format '{{.Names}}')" || return 1
  if grep -qxF -- "$CONF_CONTAINER" <<<"$existing"; then
    docker stop "$CONF_CONTAINER" >/dev/null || return 1
    docker rm "$CONF_CONTAINER" >/dev/null || return 1
  fi
  docker run -d --name "$CONF_CONTAINER" \
    --init \
    --network host \
    --restart unless-stopped \
    --memory "$CONF_MEMORY" --memory-swap "$CONF_MEMORY" \
    --log-opt max-size=10m --log-opt max-file=3 \
    -v "$CONF_ENV_FILE:/app/.env:ro" \
    --label "deploy.app=$REQ_APP" \
    --label "deploy.env=$DEPLOY_ENV" \
    --label "deploy.tag=$REQ_TAG" \
    "$CONF_IMAGE:$REQ_TAG" >/dev/null || return 1
}

# Start the app as <name> on <port>, with an optional deploy role.
run_app_container() {
  local name="$1" port="$2" role="${3-}"
  local -a role_label=()
  [ -z "$role" ] || role_label=(--label "deploy.role=$role")
  docker run -d --name "$name" \
    --init \
    --network host \
    --restart unless-stopped \
    --memory "$CONF_MEMORY" --memory-swap "$CONF_MEMORY" \
    --log-opt max-size=10m --log-opt max-file=3 \
    -e PORT="$port" \
    -v "$CONF_ENV_FILE:/app/.env:ro" \
    --label "deploy.app=$REQ_APP" \
    --label "deploy.env=$DEPLOY_ENV" \
    --label "deploy.tag=$REQ_TAG" \
    "${role_label[@]}" \
    "$CONF_IMAGE:$REQ_TAG" >/dev/null || return 1
}

# Pull, run the migration script in a one-off container, follow its output,
# wait for the exit code, remove it and log the outcome. Never returns.
run_migration() {
  local name="${CONF_CONTAINER}-migrate" existing code
  docker pull "$CONF_IMAGE:$REQ_TAG" >&2 || {
    migrate_log "migrate:$REQ_SCRIPT:fail:pull"
    die 1 "pull failed"
  }

  existing="$(docker ps -a --filter "name=^${name}\$" --format '{{.Names}}')" || {
    migrate_log "migrate:$REQ_SCRIPT:fail:leftover"
    die 1 "cannot check for a leftover $name container"
  }
  if grep -qxF -- "$name" <<<"$existing"; then
    migrate_log "migrate:$REQ_SCRIPT:fail:leftover"
    die 1 "migration container $name already exists: check docker logs $name, then docker rm $name"
  fi

  docker run -d --name "$name" \
    --init \
    --network host \
    --memory "$CONF_MEMORY" --memory-swap "$CONF_MEMORY" \
    --log-opt max-size=10m --log-opt max-file=3 \
    -v "$CONF_ENV_FILE:/app/.env:ro" \
    --label "deploy.app=$REQ_APP" \
    --label "deploy.env=$DEPLOY_ENV" \
    --label "deploy.tag=$REQ_TAG" \
    --label deploy.role=migrate \
    "$CONF_IMAGE:$REQ_TAG" \
    node "dist/scripts/$REQ_SCRIPT.js" "${REQ_ARGS[@]}" >/dev/null || {
    migrate_log "migrate:$REQ_SCRIPT:fail:run"
    die 1 "run failed"
  }

  # A dropped SSH session must not cut the migration short: finish it, keep
  # the lock, then remove the container.
  trap '' HUP INT TERM PIPE
  docker logs -f "$name" 2>&1 || true
  code="$(docker wait "$name")" || code="unknown"
  [[ "$code" =~ ^[0-9]{1,3}$ ]] || code="unknown"
  docker rm "$name" >/dev/null ||
    echo "deploy: warning: docker rm $name failed" >&2 || true

  if [ "$code" = 0 ]; then
    migrate_log "migrate:$REQ_SCRIPT:ok"
    echo "migrate: $REQ_APP $DEPLOY_ENV $REQ_TAG $REQ_SCRIPT ok" || true
    exit 0
  fi
  migrate_log "migrate:$REQ_SCRIPT:fail:exit=$code"
  echo "migrate: $REQ_SCRIPT exited $code" >&2 || true
  exit 1
}

# Wait for any HTTP answer on the port, let the container settle for
# VERIFY_SETTLE seconds (catches a crash right after the first answer), then
# require "running, 0 restarts".
verify_container() {
  local name="${1:-$CONF_CONTAINER}" port="${2:-$CONF_PORT}"
  local code state up=0 start=$SECONDS
  while :; do
    code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:$port/" 2>/dev/null)" || true
    if [ -n "$code" ] && [ "$code" != 000 ]; then
      up=1
      break
    fi
    ((SECONDS - start < VERIFY_TIMEOUT)) || break
    sleep "$VERIFY_INTERVAL"
  done

  if [ "$up" = 1 ]; then
    ((VERIFY_SETTLE == 0)) || sleep "$VERIFY_SETTLE"
    state="$(docker inspect -f '{{.State.Running}} {{.RestartCount}}' "$name" 2>/dev/null)" || state=""
    [ "$state" = "true 0" ] && return 0
    echo "deploy: container state '$state', expected 'true 0'" >&2
  else
    echo "deploy: no HTTP answer on port $port within ${VERIFY_TIMEOUT}s" >&2
  fi
  docker logs --tail 50 "$name" >&2 || true
  return 1
}

# One HTTP request to a local port; 0 when it answers with a non-empty code
# other than 000.
port_answers() {
  local code
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:$1/" 2>/dev/null)" || true
  [ -n "$code" ] && [ "$code" != 000 ]
}

# 0 when docker lists the container, 1 when it does not, 2 when docker fails.
container_exists() {
  local existing
  existing="$(docker ps -a --filter "name=^$1\$" --format '{{.Names}}')" || return 2
  grep -qxF -- "$1" <<<"$existing"
}

# Stop and remove a container; non-zero when either step fails.
remove_container() {
  docker stop -t "$STOP_TIMEOUT" "$1" >/dev/null || return 1
  docker rm "$1" >/dev/null
}

# 0 when the container exists, is running, and answers on its port.
container_healthy() {
  local name="$1" port="$2" state
  container_exists "$name" || return 1
  state="$(docker inspect -f '{{.State.Running}}' "$name" 2>/dev/null)" || return 1
  [[ "$state" == true* ]] || return 1
  port_answers "$port"
}

# Deploy through the backup port: new version up and verified there, stop the
# old main, start the new main and verify it, drain, then remove the backup.
zero_downtime_deploy() {
  local backup="${CONF_CONTAINER}-backup" serving_backup=0
  if container_exists "$backup"; then
    if container_healthy "$CONF_CONTAINER" "$CONF_PORT"; then
      echo "deploy: warning: removing stale $backup" >&2
      remove_container "$backup" ||
        echo "deploy: warning: removing $backup failed" >&2
    elif container_healthy "$backup" "$CONF_BACKUP_PORT"; then
      echo "deploy: $backup is serving; replacing the main container behind it" >&2
      if container_exists "$CONF_CONTAINER"; then
        remove_container "$CONF_CONTAINER" || true
      fi
      serving_backup=1
    else
      echo "deploy: warning: neither $CONF_CONTAINER nor $backup is serving; starting fresh" >&2
      if container_exists "$CONF_CONTAINER"; then
        remove_container "$CONF_CONTAINER" || true
      fi
      remove_container "$backup" || true
    fi
  fi

  if [ "$serving_backup" = 0 ]; then
    if port_answers "$CONF_BACKUP_PORT"; then
      echo "deploy: port $CONF_BACKUP_PORT already answers; another process uses BACKUP_PORT" >&2
      fail_step backup-port
    fi

    if ! run_app_container "$backup" "$CONF_BACKUP_PORT" backup ||
      ! verify_container "$backup" "$CONF_BACKUP_PORT"; then
      remove_container "$backup" || true
      fail_step backup
    fi

    if container_exists "$CONF_CONTAINER"; then
      if ! docker stop -t "$STOP_TIMEOUT" "$CONF_CONTAINER" >/dev/null; then
        remove_container "$backup" || true
        fail_step stop-old
      fi
      docker rm "$CONF_CONTAINER" >/dev/null || fail_step stop-old
    fi
  fi

  if ! run_app_container "$CONF_CONTAINER" "$CONF_PORT" ||
    ! verify_container; then
    docker stop -t "$STOP_TIMEOUT" "$CONF_CONTAINER" >/dev/null 2>&1 || true
    echo "deploy: the new main container failed; $backup still serves $REQ_TAG. Read docker logs $CONF_CONTAINER, then deploy a fixed or older tag." >&2
    fail_step main
  fi

  [ "$DRAIN" = 0 ] || sleep "$DRAIN"

  remove_container "$backup" ||
    echo "deploy: warning: removing $backup failed" >&2
  return 0
}

# Remove this env's images beyond the newest KEEP_IMAGES, never one in use.
prune_images() {
  local prefix="${REQ_TAG%%-*}" tag created epoch used n=0
  local -a sorted=()
  local listing in_use
  listing="$(docker images --format '{{.Tag}}\t{{.CreatedAt}}' "$CONF_IMAGE")" || {
    echo "deploy: warning: docker images failed; skipping prune" >&2
    return 0
  }
  in_use="$(docker ps -a --format '{{.Image}}')" || {
    echo "deploy: warning: docker ps failed; skipping prune" >&2
    return 0
  }

  # "<epoch>\t<tag>" for this env's deployable tags (never *-latest).
  # CreatedAt looks like "2026-10-27 10:00:00 +0300 EEST"; drop the zone name.
  while IFS=$'\t' read -r tag created; do
    [[ "$tag" =~ ^${prefix}-[0-9a-f]{7,40}$ ]] || continue
    epoch="$(date -u -d "$(cut -d' ' -f1-3 <<<"$created")" +%s 2>/dev/null)" || {
      echo "deploy: warning: unparsable CreatedAt for $tag; keeping it" >&2
      continue
    }
    sorted+=("$epoch"$'\t'"$tag")
  done <<<"$listing"
  [ "${#sorted[@]}" -gt 0 ] || { docker image prune -f >/dev/null || true; return 0; }

  while IFS=$'\t' read -r epoch tag; do
    n=$((n + 1))
    ((n > CONF_KEEP_IMAGES)) || continue
    used="$CONF_IMAGE:$tag"
    if grep -qxF -- "$used" <<<"$in_use"; then
      continue
    fi
    docker rmi "$used" >/dev/null ||
      echo "deploy: warning: docker rmi $used failed" >&2
  done < <(printf '%s\n' "${sorted[@]}" | sort -t $'\t' -k1,1nr)

  docker image prune -f >/dev/null ||
    echo "deploy: warning: docker image prune failed" >&2
}

# Integer env override or its default.
int_env() {
  local val="${!1:-$2}"
  [[ "$val" =~ ^[0-9]{1,6}$ ]] || die 2 "$1 must be an integer"
  echo "$((10#$val))"
}

main() {
  set -euo pipefail
  parse_pin "$@"
  if [ -n "${SSH_ORIGINAL_COMMAND+x}" ]; then
    # Forced command: the key's line must pin the environment, nothing else.
    [ -n "$PIN_ENV" ] || die 2 "forced command must pin --env <staging|production>"
    [ "${#ARGS[@]}" -eq 0 ] || die 2 "unexpected arguments after --env"
  fi
  read_words "${ARGS[@]}"
  VERB="${WORDS[0]-}"
  case "$VERB" in
    migrate) parse_migrate "${WORDS[@]}" ;;
    *) parse_request "${WORDS[@]}" ;;
  esac
  DEPLOY_ENV="$(env_for_tag "$REQ_TAG")"
  if [ -n "$PIN_ENV" ] && [ "$PIN_ENV" != "$DEPLOY_ENV" ]; then
    die 2 "tag $REQ_TAG deploys to $DEPLOY_ENV, but --env pins $PIN_ENV"
  fi
  load_conf "$DEPLOY_ROOT/apps/$REQ_APP-$DEPLOY_ENV.conf"
  VERIFY_TIMEOUT="$(int_env DEPLOY_VERIFY_TIMEOUT 30)"
  VERIFY_INTERVAL="$(int_env DEPLOY_VERIFY_INTERVAL 2)"
  VERIFY_SETTLE="$(int_env DEPLOY_VERIFY_SETTLE 10)"
  DRAIN="$(int_env DEPLOY_DRAIN 5)"
  STOP_TIMEOUT="$(int_env DEPLOY_STOP_TIMEOUT 10)"
  local lock_timeout lock
  lock_timeout="$(int_env DEPLOY_LOCK_TIMEOUT 600)"

  # Normally created by setup; ignore failures if they already exist.
  mkdir -p "$DEPLOY_ROOT/locks" "$DEPLOY_ROOT/logs" 2>/dev/null || true

  lock="$DEPLOY_ROOT/locks/$REQ_APP-$DEPLOY_ENV.lock"
  exec 9>>"$lock" || die 1 "cannot open lock $lock"
  if ! flock -w "$lock_timeout" 9; then
    if [ "$VERB" = migrate ]; then
      migrate_log "migrate:$REQ_SCRIPT:fail:lock"
    else
      log_result "fail:lock"
    fi
    die 4 "timed out after ${lock_timeout}s waiting for $lock"
  fi

  [ "$VERB" != migrate ] || run_migration

  docker pull "$CONF_IMAGE:$REQ_TAG" >&2 || fail_step pull
  if [ -n "$CONF_BACKUP_PORT" ]; then
    zero_downtime_deploy
  else
    swap_container || fail_step run
    verify_container || fail_step verify
  fi
  prune_images || echo "deploy: warning: prune failed" >&2
  log_result ok
  echo "deploy: $REQ_APP $DEPLOY_ENV $REQ_TAG ok"
  exit 0
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
