#!/usr/bin/env bash
# deploy.sh - generic Docker deploy, run via an SSH forced command.
# Grammar: deploy <app> <tag>   (tag: ^(staging|production)-[0-9a-f]{7,40}$)
# Invocation:
#   SSH:    authorized_keys has command="/opt/deploy/deploy.sh --env <env>";
#           the request comes from SSH_ORIGINAL_COMMAND and the pinned --env
#           is required and must match the tag's environment.
#   Manual: deploy.sh [--env <env>] deploy <app> <tag>   (--env optional)
# Exit codes: 0 ok, 1 runtime failure, 2 invalid request/conf, 3 conf missing,
#             4 lock timeout.

# Locale-proof bracket ranges such as [0-9a-f] (also when sourced by tests).
export LC_ALL=C

DEPLOY_ROOT="${DEPLOY_ROOT:-/opt/deploy}"

die() {
  local code="$1"
  shift
  echo "deploy: $*" >&2
  exit "$code"
}

# Leading "--env <staging|production>" from argv; sets PIN_ENV ("" if absent)
# and ARGS (the remaining arguments).
parse_pin() {
  PIN_ENV=""
  if [ "${1-}" = --env ]; then
    [ "$#" -ge 2 ] || die 2 "--env needs a value"
    case "$2" in
      staging | production) PIN_ENV="$2" ;;
      *) die 2 "invalid --env (staging or production)" ;;
    esac
    shift 2
  fi
  ARGS=("$@")
}

# Fill WORDS from SSH_ORIGINAL_COMMAND (if set) or from the arguments.
read_words() {
  WORDS=()
  if [ -n "${SSH_ORIGINAL_COMMAND+x}" ]; then
    set -f
    IFS=$' \t\n' read -r -d '' -a WORDS <<<"$SSH_ORIGINAL_COMMAND" || true
    set +f
  else
    WORDS=("$@")
  fi
}

# Validate "deploy <app> <tag>"; sets REQ_APP and REQ_TAG.
parse_request() {
  [ "$#" -eq 3 ] || die 2 "expected: deploy <app> <tag>"
  [ "$1" = deploy ] || die 2 "unknown command"
  case "$2" in
    backend) ;;
    *) die 2 "unknown app" ;;
  esac
  [[ "$3" =~ ^(staging|production)-[0-9a-f]{7,40}$ ]] || die 2 "invalid tag"
  # shellcheck disable=SC2034 # consumed by later steps in main
  REQ_APP="$2"
  # shellcheck disable=SC2034
  REQ_TAG="$3"
}

env_for_tag() {
  case "$1" in
    staging-*) echo staging ;;
    production-*) echo production ;;
  esac
}

# Parse a per-app-env conf as data (never sourced/eval'd) and set
# CONF_IMAGE, CONF_CONTAINER, CONF_PORT, CONF_ENV_FILE, CONF_MEMORY,
# CONF_KEEP_IMAGES. Missing file -> exit 3; any invalid content -> exit 2.
load_conf() {
  local path="$1" line key val
  local -A seen=()
  [ -f "$path" ] || die 3 "conf not found: $path"
  [ -r "$path" ] || die 3 "conf not readable: $path"

  while IFS= read -r line || [ -n "$line" ]; do
    [[ "$line" =~ ^[[:space:]]*(#.*)?$ ]] && continue
    [[ "$line" == *=* ]] || die 2 "conf: malformed line"
    key="${line%%=*}"
    val="${line#*=}"
    case "$key" in
      IMAGE | CONTAINER | PORT | ENV_FILE | MEMORY | KEEP_IMAGES) ;;
      *) die 2 "conf: unknown key" ;;
    esac
    [ -z "${seen[$key]+x}" ] || die 2 "conf: duplicate key $key"
    seen[$key]="$val"
  done <"$path"

  for key in IMAGE CONTAINER PORT ENV_FILE MEMORY KEEP_IMAGES; do
    [ -n "${seen[$key]+x}" ] || die 2 "conf: missing key $key"
  done

  # Optional "host:port/" registry prefix; no tag or digest.
  [[ "${seen[IMAGE]}" =~ ^([a-z0-9][a-z0-9.-]*:[0-9]{1,5}/)?[a-z0-9][a-z0-9./_-]*$ ]] ||
    die 2 "conf: invalid IMAGE"
  [[ "${seen[CONTAINER]}" =~ ^[a-z0-9][a-z0-9_.-]*$ ]] || die 2 "conf: invalid CONTAINER"
  [[ "${seen[PORT]}" =~ ^[0-9]{1,5}$ ]] || die 2 "conf: invalid PORT"
  ((10#${seen[PORT]} >= 1 && 10#${seen[PORT]} <= 65535)) || die 2 "conf: invalid PORT"
  [[ "${seen[ENV_FILE]}" =~ ^/[A-Za-z0-9._/-]+$ ]] || die 2 "conf: invalid ENV_FILE"
  [ -f "${seen[ENV_FILE]}" ] || die 2 "conf: ENV_FILE is not a regular file"
  # A zero limit means "unlimited" to Docker, so require a non-zero number.
  [[ "${seen[MEMORY]}" =~ ^0*[1-9][0-9]*[kmg]$ ]] || die 2 "conf: invalid MEMORY"
  [[ "${seen[KEEP_IMAGES]}" =~ ^[0-9]{1,6}$ ]] || die 2 "conf: invalid KEEP_IMAGES"
  ((10#${seen[KEEP_IMAGES]} >= 1)) || die 2 "conf: invalid KEEP_IMAGES"

  # shellcheck disable=SC2034 # consumed by later steps in main
  CONF_IMAGE="${seen[IMAGE]}"
  # shellcheck disable=SC2034
  CONF_CONTAINER="${seen[CONTAINER]}"
  # shellcheck disable=SC2034
  CONF_PORT="$((10#${seen[PORT]}))"
  # shellcheck disable=SC2034
  CONF_ENV_FILE="${seen[ENV_FILE]}"
  # shellcheck disable=SC2034
  CONF_MEMORY="${seen[MEMORY]}"
  # shellcheck disable=SC2034
  CONF_KEEP_IMAGES="$((10#${seen[KEEP_IMAGES]}))"
}

# Append one outcome line to the deploy log; never fails the deploy.
log_result() {
  local line
  line="$(date -u +%Y-%m-%dT%H:%M:%SZ) app=$REQ_APP env=$DEPLOY_ENV tag=$REQ_TAG result=$1"
  echo "$line" >>"$DEPLOY_ROOT/logs/deploy.log" 2>/dev/null ||
    echo "deploy: warning: could not write deploy.log: $line" >&2
}

fail_step() {
  log_result "fail:$1"
  die 1 "$1 failed"
}

# Stop and remove the current container (if any), then start the new one.
swap_container() {
  local existing
  existing="$(docker ps -a --filter "name=^${CONF_CONTAINER}\$" --format '{{.Names}}')" || return 1
  if grep -qxF -- "$CONF_CONTAINER" <<<"$existing"; then
    docker stop "$CONF_CONTAINER" >/dev/null || return 1
    docker rm "$CONF_CONTAINER" >/dev/null || return 1
  fi
  docker run -d --name "$CONF_CONTAINER" \
    --init \
    --network host \
    --restart unless-stopped \
    --memory "$CONF_MEMORY" --memory-swap "$CONF_MEMORY" \
    --log-opt max-size=10m --log-opt max-file=3 \
    -v "$CONF_ENV_FILE:/app/.env:ro" \
    --label "deploy.app=$REQ_APP" \
    --label "deploy.env=$DEPLOY_ENV" \
    --label "deploy.tag=$REQ_TAG" \
    "$CONF_IMAGE:$REQ_TAG" >/dev/null || return 1
}

# Wait for any HTTP answer on the port, let the container settle for
# VERIFY_SETTLE seconds (catches a crash right after the first answer), then
# require "running, 0 restarts".
verify_container() {
  local code state up=0 start=$SECONDS
  while :; do
    code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:$CONF_PORT/" 2>/dev/null)" || true
    if [ -n "$code" ] && [ "$code" != 000 ]; then
      up=1
      break
    fi
    ((SECONDS - start < VERIFY_TIMEOUT)) || break
    sleep "$VERIFY_INTERVAL"
  done

  if [ "$up" = 1 ]; then
    ((VERIFY_SETTLE == 0)) || sleep "$VERIFY_SETTLE"
    state="$(docker inspect -f '{{.State.Running}} {{.RestartCount}}' "$CONF_CONTAINER" 2>/dev/null)" || state=""
    [ "$state" = "true 0" ] && return 0
    echo "deploy: container state '$state', expected 'true 0'" >&2
  else
    echo "deploy: no HTTP answer on port $CONF_PORT within ${VERIFY_TIMEOUT}s" >&2
  fi
  docker logs --tail 50 "$CONF_CONTAINER" >&2 || true
  return 1
}

# Remove this env's images beyond the newest KEEP_IMAGES, never one in use.
prune_images() {
  local prefix="${REQ_TAG%%-*}" tag created epoch used n=0
  local -a sorted=()
  local listing in_use
  listing="$(docker images --format '{{.Tag}}\t{{.CreatedAt}}' "$CONF_IMAGE")" || {
    echo "deploy: warning: docker images failed; skipping prune" >&2
    return 0
  }
  in_use="$(docker ps -a --format '{{.Image}}')" || {
    echo "deploy: warning: docker ps failed; skipping prune" >&2
    return 0
  }

  # "<epoch>\t<tag>" for this env's deployable tags (never *-latest).
  # CreatedAt looks like "2026-10-27 10:00:00 +0300 EEST"; drop the zone name.
  while IFS=$'\t' read -r tag created; do
    [[ "$tag" =~ ^${prefix}-[0-9a-f]{7,40}$ ]] || continue
    epoch="$(date -u -d "$(cut -d' ' -f1-3 <<<"$created")" +%s 2>/dev/null)" || {
      echo "deploy: warning: unparsable CreatedAt for $tag; keeping it" >&2
      continue
    }
    sorted+=("$epoch"$'\t'"$tag")
  done <<<"$listing"
  [ "${#sorted[@]}" -gt 0 ] || { docker image prune -f >/dev/null || true; return 0; }

  while IFS=$'\t' read -r epoch tag; do
    n=$((n + 1))
    ((n > CONF_KEEP_IMAGES)) || continue
    used="$CONF_IMAGE:$tag"
    if grep -qxF -- "$used" <<<"$in_use"; then
      continue
    fi
    docker rmi "$used" >/dev/null ||
      echo "deploy: warning: docker rmi $used failed" >&2
  done < <(printf '%s\n' "${sorted[@]}" | sort -t $'\t' -k1,1nr)

  docker image prune -f >/dev/null ||
    echo "deploy: warning: docker image prune failed" >&2
}

# Integer env override or its default.
int_env() {
  local val="${!1:-$2}"
  [[ "$val" =~ ^[0-9]{1,6}$ ]] || die 2 "$1 must be an integer"
  echo "$((10#$val))"
}

main() {
  set -euo pipefail
  parse_pin "$@"
  if [ -n "${SSH_ORIGINAL_COMMAND+x}" ]; then
    # Forced command: the key's line must pin the environment, nothing else.
    [ -n "$PIN_ENV" ] || die 2 "forced command must pin --env <staging|production>"
    [ "${#ARGS[@]}" -eq 0 ] || die 2 "unexpected arguments after --env"
  fi
  read_words "${ARGS[@]}"
  parse_request "${WORDS[@]}"
  DEPLOY_ENV="$(env_for_tag "$REQ_TAG")"
  if [ -n "$PIN_ENV" ] && [ "$PIN_ENV" != "$DEPLOY_ENV" ]; then
    die 2 "tag $REQ_TAG deploys to $DEPLOY_ENV, but --env pins $PIN_ENV"
  fi
  load_conf "$DEPLOY_ROOT/apps/$REQ_APP-$DEPLOY_ENV.conf"
  VERIFY_TIMEOUT="$(int_env DEPLOY_VERIFY_TIMEOUT 30)"
  VERIFY_INTERVAL="$(int_env DEPLOY_VERIFY_INTERVAL 2)"
  VERIFY_SETTLE="$(int_env DEPLOY_VERIFY_SETTLE 10)"
  local lock_timeout lock
  lock_timeout="$(int_env DEPLOY_LOCK_TIMEOUT 600)"

  # Normally created by setup; ignore failures if they already exist.
  mkdir -p "$DEPLOY_ROOT/locks" "$DEPLOY_ROOT/logs" 2>/dev/null || true

  lock="$DEPLOY_ROOT/locks/$REQ_APP-$DEPLOY_ENV.lock"
  exec 9>>"$lock" || die 1 "cannot open lock $lock"
  if ! flock -w "$lock_timeout" 9; then
    log_result "fail:lock"
    die 4 "timed out after ${lock_timeout}s waiting for $lock"
  fi

  docker pull "$CONF_IMAGE:$REQ_TAG" >&2 || fail_step pull
  swap_container || fail_step run
  verify_container || fail_step verify
  prune_images || echo "deploy: warning: prune failed" >&2
  log_result ok
  echo "deploy: $REQ_APP $DEPLOY_ENV $REQ_TAG ok"
  exit 0
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
