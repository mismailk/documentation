#!/usr/bin/env bash
# One-time, idempotent server setup. Run as root from the copied server/ directory:
#   sudo ./server-setup.sh [--skip-docker] [--skip-swap] [ENV:PUBKEY_FILE...]
# ENV is staging or production: each key may only deploy to that environment
# (its authorized_keys line runs "deploy.sh --env ENV").
# Never touches nginx, MongoDB or pm2.
set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_ROOT=/opt/deploy
DEPLOYER=deployer
SWAPFILE="${SWAPFILE:-/swapfile}"
FSTAB="${FSTAB:-/etc/fstab}"
SWAP_MIN_FREE=$((3 * 1024 * 1024 * 1024)) # 2 GiB swapfile + 1 GiB margin
SKIP_DOCKER=0
SKIP_SWAP=0
PUBKEYS=() # "env:file" entries

log() { echo "==> $*"; }
warn() { echo "WARNING: $*" >&2; }
die() { echo "error: $*" >&2; exit 1; }

# 1. Docker Engine from Docker's official apt repo.
install_docker() {
  if command -v snap >/dev/null 2>&1 && snap list docker >/dev/null 2>&1; then
    die "Docker is installed as a snap; remove it first (snap remove docker) or use --skip-docker"
  fi
  if ! dpkg -s docker-ce >/dev/null 2>&1; then
    if dpkg -s docker.io >/dev/null 2>&1; then
      die "docker.io is installed; installing docker-ce would replace it and could stop running containers. Migrate manually or use --skip-docker"
    fi
    if command -v docker >/dev/null 2>&1; then
      die "a non-docker-ce docker binary is already present ($(command -v docker)); not installing over it. Use --skip-docker"
    fi
  fi
  if dpkg -s docker-ce >/dev/null 2>&1; then
    log "docker-ce already installed"
  else
    log "installing Docker Engine"
    export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
    apt-get update
    apt-get install -y ca-certificates curl
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc
    # shellcheck disable=SC1091
    cat >/etc/apt/sources.list.d/docker.sources <<SRC
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $(. /etc/os-release && echo "$VERSION_CODENAME")
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
SRC
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin
  fi
  systemctl enable --now docker
}

# 2. Swap, only when the server has none at all.
free_bytes_root() { df --output=avail -B1 / | tail -n 1 | tr -d ' '; }

ensure_fstab_entry() {
  grep -qE "^${SWAPFILE}[[:space:]]" "$FSTAB" && return 0
  [ -e "$FSTAB.bak-deploy" ] || cp -p "$FSTAB" "$FSTAB.bak-deploy"
  # make sure the last existing line ends in a newline before appending
  if [ -s "$FSTAB" ] && [ -n "$(tail -c 1 "$FSTAB")" ]; then
    echo >>"$FSTAB"
  fi
  echo "$SWAPFILE none swap sw 0 0" >>"$FSTAB"
}

apply_swappiness() {
  echo 'vm.swappiness=10' >/etc/sysctl.d/99-deploy-swap.conf
  sysctl -p /etc/sysctl.d/99-deploy-swap.conf
}

# True if the file carries a swap signature (SWAPSPACE2 at offset 4086).
has_swap_signature() {
  [ "$(dd if="$1" bs=1 skip=4086 count=10 2>/dev/null)" = "SWAPSPACE2" ]
}

# Build and activate a new swapfile; remove it again if anything fails.
create_swapfile() {
  if ! { { fallocate -l 2G "$SWAPFILE" || dd if=/dev/zero of="$SWAPFILE" bs=1M count=2048; } &&
    chmod 600 "$SWAPFILE" && mkswap "$SWAPFILE" && swapon "$SWAPFILE"; }; then
    rm -f "$SWAPFILE"
    warn "creating swap failed; removed $SWAPFILE. Re-run to retry"
    return 1
  fi
}

setup_swap() {
  if [ -n "$(swapon --show)" ]; then
    log "swap already active; leaving it alone"
    return 0
  fi
  if [ -e "$SWAPFILE" ] || [ -L "$SWAPFILE" ]; then
    # Left over from a previous partial run (or someone else): only reuse if provably swap.
    if [ -f "$SWAPFILE" ] && [ ! -L "$SWAPFILE" ] &&
      [ "$(stat -c '%U %a' "$SWAPFILE")" = "root 600" ] && has_swap_signature "$SWAPFILE"; then
      log "activating existing inactive $SWAPFILE"
      swapon "$SWAPFILE" || { warn "could not activate $SWAPFILE; skipping swap"; return 0; }
    else
      warn "$SWAPFILE exists but is not a root-owned 600 swap file; leaving it alone and skipping swap"
      return 0
    fi
  else
    local avail
    avail="$(free_bytes_root)"
    if [ "$avail" -lt "$SWAP_MIN_FREE" ]; then
      warn "only $avail bytes free on /, need $SWAP_MIN_FREE (2G swap + 1G margin); skipping swap"
      return 0
    fi
    log "creating 2G $SWAPFILE"
    create_swapfile || return 0
  fi
  ensure_fstab_entry
  apply_swappiness
}

# 3. docker group, deployer user, docker access for ubuntu.
setup_users() {
  groupadd -f docker
  if id "$DEPLOYER" >/dev/null 2>&1; then
    log "user $DEPLOYER exists"
  else
    log "creating user $DEPLOYER"
    useradd --system --create-home --shell /bin/bash "$DEPLOYER"
  fi
  passwd -l "$DEPLOYER" >/dev/null
  usermod -aG docker "$DEPLOYER"
  if id ubuntu >/dev/null 2>&1; then
    usermod -aG docker ubuntu
  fi
}

# 4. /opt/deploy layout and deploy.sh.
setup_layout() {
  [ -f "$SELF_DIR/deploy.sh" ] || die "deploy.sh not found next to server-setup.sh"
  install -d -o root -g root -m 755 "$DEPLOY_ROOT" "$DEPLOY_ROOT/apps"
  install -d -o "$DEPLOYER" -g "$DEPLOYER" -m 755 "$DEPLOY_ROOT/locks" "$DEPLOY_ROOT/logs"
  install -o root -g root -m 755 "$SELF_DIR/deploy.sh" "$DEPLOY_ROOT/deploy.sh"
}

# 5. Authorize keys with a forced command pinned to one environment.
# The authorized_keys line for <env> and <key>.
key_entry() {
  echo "restrict,command=\"$DEPLOY_ROOT/deploy.sh --env $1\" $2"
}

setup_keys() {
  [ "${#PUBKEYS[@]}" -gt 0 ] || return 0
  local home ssh_dir ak spec env f key entry
  home="$(getent passwd "$DEPLOYER" | cut -d: -f6)"
  ssh_dir="$home/.ssh"
  ak="$ssh_dir/authorized_keys"
  install -d -o "$DEPLOYER" -g "$DEPLOYER" -m 700 "$ssh_dir"
  [ -e "$ak" ] || install -o "$DEPLOYER" -g "$DEPLOYER" -m 600 /dev/null "$ak"
  for spec in "${PUBKEYS[@]}"; do
    env="${spec%%:*}"
    f="${spec#*:}"
    while IFS= read -r key || [ -n "$key" ]; do
      key="${key%$'\r'}"
      case "$key" in '' | '#'*) continue ;; esac
      entry="$(key_entry "$env" "$key")"
      if grep -qxF -- "$entry" "$ak"; then
        log "key already authorized for $env: ${key:0:40}..."
      elif grep -qF -- "$key" "$ak"; then
        warn "key from $f is already in $ak but NOT as the exact '$env' line (unrestricted, old format, or pinned to another environment?). Fix it by hand; not modified."
      else
        echo "$entry" >>"$ak"
        log "authorized key from $f for $env"
      fi
    done <"$f"
  done
  chown "$DEPLOYER:$DEPLOYER" "$ak"
  chmod 600 "$ak"
}

# 6. What the admin still has to do by hand.
print_next_steps() {
  cat <<'MSG'

Setup complete. Remaining manual steps (see the walkthrough):
  1. Log in to GHCR as deployer (walkthrough: "GHCR login"):
       sudo -u deployer docker login ghcr.io
  2. Create the per-app conf files in /opt/deploy/apps/ (walkthrough: "App conf files").
  3. Check the firewall: ufw status (walkthrough: "Firewall check"); the app ports
     must not be opened publicly unless intended.
  4. Authorize CI keys by re-running: sudo ./server-setup.sh staging:PUBKEY_FILE
     (or production:PUBKEY_FILE; each key may only deploy to its environment)
MSG
}

main() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --skip-docker) SKIP_DOCKER=1 ;;
      --skip-swap) SKIP_SWAP=1 ;;
      -*) die "unknown option: $1" ;;
      staging:?* | production:?*)
        [ -r "${1#*:}" ] || die "cannot read public key file: ${1#*:}"
        PUBKEYS+=("$1")
        ;;
      *) die "key argument must be <staging|production>:<file>, got: $1" ;;
    esac
    shift
  done
  [ "$(id -u)" -eq 0 ] || die "must be run as root (use sudo)"

  [ "$SKIP_DOCKER" -eq 1 ] || install_docker
  [ "$SKIP_SWAP" -eq 1 ] || setup_swap
  setup_users
  setup_layout
  setup_keys
  print_next_steps
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
  main "$@"
fi
