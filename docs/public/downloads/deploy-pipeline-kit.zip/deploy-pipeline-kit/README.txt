Deploy Pipeline kit
===================

Server files for the Docker deploy pipeline, shared by every app on it.
Follow the Deploy Pipeline guide; it says when to use each file. The
templates for your app repo are in your app guide's kit (Express or Next.js).

server/                       copied to the server (guide stages 2 and 3)
  deploy.sh                   installed as /opt/deploy/deploy.sh; holds the app whitelist
  server-setup.sh             one-time, idempotent server setup (run with sudo);
                              also adds CI keys and reinstalls deploy.sh
  app.conf.template           template for /opt/deploy/apps/<app>-<env>.conf
